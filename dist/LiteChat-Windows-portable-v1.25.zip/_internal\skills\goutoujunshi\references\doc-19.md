# 核心书单与论文索引

## 一、关系科学与心理学

- Rowland S. Miller, *Intimate Relationships*（罗兰·米勒《亲密关系》）：关系研究综合教材之一，可用于查阅相识与吸引、社会交换、承诺、权力、冲突和关系压力等主题；具体结论仍需回到原始研究并核对版本。[McGraw Hill书目](https://www.mheducation.com/highered/product/Intimate-Relationships-Miller.html)
- Bowlby, *Attachment and Loss*：依恋理论奠基；历史重要，成人恋爱应用需结合后续研究。
- Mikulincer & Shaver, *Attachment in Adulthood*：成人依恋研究的系统参考。
- Reis & Shaver (1988), interpersonal process model of intimacy：自我披露—伴侣回应—感知理解/确认/关心。
- Karney & Bradbury (1995), vulnerability-stress-adaptation model：个人脆弱性、外部压力与适应过程。
- Rusbult, investment model：满意度、替代选择、投入与承诺。
- Aron & Aron, self-expansion model：关系中的共同成长和新颖活动。
- Joel et al. (2020), [43 个纵向伴侣数据集的关系质量预测](https://www.pnas.org/doi/10.1073/pnas.1917036117).

## 二、伴侣沟通与治疗

- Christensen & Jacobson, *Reconcilable Differences*：整合行为伴侣治疗的普及读物。
- Johnson, *Attachment Theory in Practice*：情绪取向治疗及依恋框架；属于治疗模型，不等于所有技术都有独立强证据。
- Gottman & Silver, *The Seven Principles for Making Marriage Work*：流行关系教育框架；使用时区分研究发现、临床模型与品牌化表述。
- Rosenberg, *Nonviolent Communication*：观察—感受—需要—请求框架；适合作表达练习，不应宣称万能或用于暴力关系共同谈判。
- Joseph et al. (2025), [伴侣干预系统综述与元分析](https://pmc.ncbi.nlm.nih.gov/articles/PMC11787838/).
- Kuhn et al. (2018), [压力对话中的倾听](https://pubmed.ncbi.nlm.nih.gov/29863374/).

## 三、人格与测量

- McCrae & Costa (1989), [从五因素模型重释 MBTI](https://scholars.duke.edu/publication/1458465).
- John, Naumann & Soto, Big Five taxonomy：五因素模型综述。
- Malouff et al. (2010), Five-Factor Model and relationship satisfaction meta-analysis：人格与满意度关联总体有限。
- MBTI 官方 [validity/reliability materials](https://www.themyersbriggs.com/en-US/Support/Validity-of-the-Myers-Briggs-assessment)：需与独立测量研究并读。

## 四、爱与婚姻哲学

- 柏拉图《会饮》《斐德罗》：欲望、美与灵魂提升。
- 亚里士多德《尼各马可伦理学》VIII–IX：功用、快乐与德性友爱。
- Martin Buber, *I and Thou*：《我与你》，主体相遇与工具化关系。
- Erich Fromm, *The Art of Loving*：《爱的艺术》，爱作为能力与实践；不当作实证心理学手册。
- Simone de Beauvoir, *The Second Sex*；*The Ethics of Ambiguity*：自由、他者化、性别与伦理。
- bell hooks, *All About Love*：关怀、责任、尊重与文化批判。
- [SEP: Love](https://plato.stanford.edu/entries/love/)，[SEP: Marriage and Domestic Partnership](https://plato.stanford.edu/entries/marriage/).

## 五、家庭社会学与现代性

- Stephanie Coontz, *Marriage, a History*：婚姻从经济/家族制度到爱情理想的历史。
- Anthony Giddens, *The Transformation of Intimacy*：纯粹关系、性与现代亲密；作为理论读物，不当作经验定律。
- Ulrich Beck & Elisabeth Beck-Gernsheim, *The Normal Chaos of Love*：个体化、风险与亲密关系。
- Andrew Cherlin (2004), “The Deinstitutionalization of American Marriage”：美国婚姻规范变化，不能直接套用中国。
- Eli Finkel, *The All-or-Nothing Marriage*：高期待婚姻与资源条件。
- Eva Illouz, *Why Love Hurts*；*Consuming the Romantic Utopia*：市场、文化资本与浪漫爱情。
- OECD, [Family Database](https://www.oecd.org/en/data/datasets/oecd-family-database.html).
- UN, [World Marriage Data](https://www.un.org/development/desa/pd/node/3593).

## 六、中国婚姻、家庭与法律

- 费孝通《乡土中国》《生育制度》：家庭、亲属与社会结构；需结合时代变化阅读。
- 阎云翔《私人生活的变革》：中国社会个体化、家庭与情感变迁的民族志。
- 潘绥铭等中国性社会学研究：理解性观念与行为变迁；注意抽样和年代。
- [1950 年《婚姻法》](https://www.npc.gov.cn/WZWSREL3pncmR3L25wYy9sZnp0L3JseXMvMjAxNC0xMC8yNC9jb250ZW50XzE4ODI3MjMuaHRt).
- [《中华人民共和国民法典》](https://www.court.gov.cn/zixun/xiangqing/233181.html).
- [《反家庭暴力法》](https://www.npc.gov.cn/npc/c2/c10134/201905/t20190521_260193.html).
- [2025 年《婚姻登记条例》](https://www.gov.cn/zhengce/content/202504/content_7017751.htm).
- [国家统计局 2025 年国民经济和社会发展统计公报](https://www.stats.gov.cn/sj/zxfb/202602/t20260228_1962662.html).

## 七、在线约会、PUA 与数字安全

- Pew Research Center (2023), [Online Dating in the U.S.](https://www.pewresearch.org/internet/2023/02/02/from-looking-for-love-to-swiping-the-field-online-dating-in-the-u-s/).
- Degen & Kleeberg-Niepage (2025), [online dating qualitative research scoping review](https://pmc.ncbi.nlm.nih.gov/articles/PMC11939417/).
- Ribeiro et al. (2020), [The Evolution of the Manosphere Across the Web](https://arxiv.org/abs/2001.07600).
- WHO, [Intimate partner violence / violence against women](https://www.who.int/health-topics/violence-against-women).
- 公安机关对“杀猪盘”、裸聊敲诈、投资诈骗的最新官方提醒，应按使用日期重新检索。

## 八、性、同意与多元关系

- WHO, [Sexual health and well-being](https://www.who.int/teams/sexual-and-reproductive-health-and-research-%28srh%29/areas-of-work/sexual-health).
- Mallory et al., [Sexual communication meta-analysis](https://pubmed.ncbi.nlm.nih.gov/34968095/).
- Cao et al. (2017), [Sexual minority stress and relationship well-being meta-analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC5627620/).
- Mogilski et al. (2025), [Monogamy vs. consensual non-monogamy satisfaction meta-analysis](https://pubmed.ncbi.nlm.nih.gov/40126203/).

## 九、扩展材料的检索式建议

优先在 PubMed、PsycINFO、Web of Science、Google Scholar 与官方统计/法律网站使用：

- `romantic relationship satisfaction meta-analysis dyadic longitudinal`
- `adult attachment emotion regulation couples systematic review`
- `demand withdraw communication meta-analysis couples`
- `transition to parenthood relationship satisfaction meta-analysis`
- `online dating systematic review self-presentation safety`
- `minority stress relationship well-being meta-analysis`
- `中国 婚姻登记 民政事业发展统计公报`
- `site:stats.gov.cn 家庭户规模 初婚 年龄`
- `site:court.gov.cn 婚姻家庭编 司法解释`
- `site:npc.gov.cn 反家庭暴力法 人身安全保护令`

检索到新材料后记录：样本、地区、研究设计、主要效应、因果限制、是否双人数据、发表年份与利益冲突。
